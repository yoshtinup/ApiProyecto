import { createMessage } from "../services/twilioService.js";

export const sendSMS = async (req, res) => {
  const { to, message } = req.body;

  try {
    const messageId = await createMessage(to, message);
    res.status(200).json({ success: true, messageId });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};