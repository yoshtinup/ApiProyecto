// router/twilioRouter.js
import express from "express";

import { sendSMS } from "../controllers/twilioController.js";

const sencdrouter = express.Router();

sencdrouter.post("/send-sms", sendSMS);

export default sencdrouter;
