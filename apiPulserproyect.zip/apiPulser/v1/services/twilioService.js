// services/twilioService.js
import twilio from "twilio";

// Credenciales de Twilio desde el archivo .env
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;

// Inicializa el cliente Twilio
const client = twilio(accountSid, authToken);

// Función para crear y enviar un mensaje SMS
export const createMessage = async (to, body) => {
  try {
    const message = await client.messages.create({
      body: body,
      from: "+19252755866", // Número de Twilio desde el archivo .env
      to: to,
    });

    console.log(`Mensaje enviado a ${to}: ${message.body}`);
    return message.sid;
  } catch (error) {
    console.error("Error al enviar el mensaje:", error);
    throw error;
  }
};

